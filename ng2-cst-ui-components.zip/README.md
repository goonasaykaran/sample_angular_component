### Initial Setup
**Make sure you have Node version >= 5.0 and NPM >= 3**

```bash
# clone our repo
# --depth 1 removes all but one .git commit history
git clone --depth 1 http://gitlab.dev.apps.cs.sgp.dbs.com/cap/ng2-cst-ui-components.git

# change directory to our repo
cd ng2-cst-ui-components

# install the repo with npm
npm install
cd to ng2-cst-ui-components/dist

# Update, 08 Feb 2017
Due to recent instability with Artifactory, you are advised to try the following steps until the Artifactory issue is resolved
1. Download compressed node_module directory 
http://artifactory.dev.sys.cs.sgp.dbs.com/artifactory/webapp/#/artifacts/browse/tree/General/cst-ui-node-backup/cst_ui_components_node_modules.zip
2. Extract to your project directory (replace any existing node_module that already exist)

```

### Starting your Application

```bash
# These steps has do be done only for the first time.  By Default, your application url is http://localhost:3000
1. Run the Build "npm run build:npm"
2. cd to ng2-cst-ui-components/dist
3. Run "npm link". This creates a symbolic link from a global folder to the ng2-cst-ui-components/dist folder
4. cd to ng2-cst-ui-components/demo/src
5. Run "npm link ng2-cst-ui-components".

# Start the Application
npm run start

# Start the demo server with hot module reloading
npm run server:dev:hmr

# watch and build files
npm run watch

```

### Running your Quality Gates
**The project is setup with 3 layers of Quality Gates.  Unit Testing with Jasmine and Karma, Linters (for Code Smell), E2E Automated Testing with Protractor**
```bash
# Running Unit Test
npm run test

# Running SASS Lint
npm run cst-sass-lint

# Running TS Lint
npm run cst-tslint



# Running Protractor
1. Start your application by running "npm run start"
2. Open a new command prompt window and start the web driver "npm run webdriver:start"
3. Open a new command prompt and run "npm run e2e"

```

## File Structure
We use the component approach in our package. This is the new standard for developing Angular apps and a great way to ensure maintainable code by encapsulation of our behavior logic. A component is basically a self contained app usually in a single file or a folder with each concern as a file: style, template, specs, e2e, module, and component class. Here's how it looks:
```
ng2-cst-ui-components/
 ├──config/                    * our configuration
 |   ├──helpers.js             * helper functions for our configuration files
 |   ├──spec-bundle.js         * ignore this magic that sets up our angular 2 testing environment
 |   ├──karma.conf.js          * karma config for our unit tests
 |   ├──protractor.conf.js     * protractor config for our end-to-end tests
 │   ├──webpack.dev.js         * our development webpack config
 │   ├──webpack.prod.js        * our production webpack config
 │   └──webpack.test.js        * our testing webpack config
 │   └──webpack.npmpackage.js  * our npm webpack config
 │
 ├──qrp/src/                   * our quick reference page source files that will be compiled to javascript
 |   ├──main.browser.ts        * our entry file for our browser environment
 │   │
 |   ├──index.html             * Index.html: where we generate our index page
 │   │
 |   ├──polyfills.ts           * our polyfills file
 │   │
 |   ├──vendor.browser.ts      * our vendor file
 │   │
 │   ├──app/                   * WebApp: folder
 │   │   ├──app.spec.ts        * a simple test of components in app.ts
 │   │   ├──app.e2e.ts         * a simple end-to-end test for /
 │   │   └──app.ts             * App.ts: a simple version of our App component components
 │   │
 │   └──assets/                * static assets are served here
 │       ├──icon/              * our list of icons from www.favicon-generator.org
 │       ├──service-worker.js  * ignore this. Web App service worker that's not complete yet
 │       ├──robots.txt         * for search engines to crawl your website
 │       └──humans.txt         * for humans to know who the developers are
 ├──qrp/e2e/                   * our e2e tests for the quick reference page
 ├──src/                       * our npm package source files that will be compiled to javascript
 |   ├──tsconfig.json          * config that webpack uses for typescript
 │   │
 |   ├──index.ts               * a barrel file to export all the components
 │   │
 |   ├──cst-dropdwon           * our component modules
 | 	 |	 ├──cst-dropdwon.component.ts     * a dropdoen component definition
 | 	 |	 ├──cst-dropdwon.component.html   * a view of the dropdown component
 | 	 |	 ├──cst-dropdwon.component.spec.ts* a test of components in cst-dropdwon.component.ts
 | 	 |	 ├──cst-dropdwon.component.css    * a css for the dropdown component
 | 	 |	 ├──cst-dropdwon.module.ts        * a module for the dropdown component to include its associates and declarations
 |   | 	 ├──index.ts                      * a barrel file to export dropdown components and its module
 |   ├──. <Other components follows>
 |   ├──.
 |   ├──.
 │   │
 │   ├──package.json           * what npm uses to manage it's dependencies
 │
 ├──node_modules/              * the dependencies that will be installed together with Kendo UI components
 ├──tslint.json                * typescript lint config
 ├──typedoc.json               * typescript documentation generator
 ├──tsconfig.json              * config that webpack uses for typescript
 ├──package.json               * what npm uses to manage it's dependencies
 └──webpack.config.js          * webpack main configuration file

```
## Dependencies
What you need to run this app:
* `node` and `npm` (`brew install node`)
* Ensure you're running the latest versions Node `v4.x.x`+ (or `v5.x.x`) and NPM `3.x.x`+


## Configuration
Configuration files live in `config/` we are currently using webpack, karma, and protractor for different stages of your application

## Contributing
You can include more components but they must introduce a new concept with the standards mentioned above. Feel free to open a Merge-Request

## TypeScript
> To take full advantage of TypeScript with autocomplete you would have to install it globally and use an editor with the correct TypeScript plugins.

## Use latest TypeScript compiler
TypeScript 1.7.x includes everything you need. Make sure to upgrade, even if you installed TypeScript previously.

```
npm install --global typescript
```

## Use a TypeScript-aware editor
We have good experience using these editors:

* [Visual Studio Code](https://code.visualstudio.com/)
* [Webstorm 10](https://www.jetbrains.com/webstorm/download/)
* [Atom](https://atom.io/) with [TypeScript plugin](https://atom.io/packages/atom-typescript)
* [Sublime Text](http://www.sublimetext.com/3) with [Typescript-Sublime-Plugin](https://github.com/Microsoft/Typescript-Sublime-plugin#installation)

### Visual Studio Code + Debugger for Chrome
> Install [Debugger for Chrome](https://marketplace.visualstudio.com/items?itemName=msjsdiag.debugger-for-chrome) and see docs for instructions to launch Chrome 

The included `.vscode` automatically connects to the webpack development server on port `3000`.

# Types
> When you include a module that doesn't include Type Definitions inside of the module you can include external Type Definitions with @types

i.e, to have youtube api support, run this command in terminal: 
```shell
npm i @types/youtube @types/gapi @types/gapi.youtube
``` 
In some cases where your code editor doesn't support Typescript 2 yet or these types weren't listed in ```tsconfig.json```, add these to **"src/custom-typings.d.ts"** to make peace with the compile check: 
```es6
import '@types/gapi.youtube';
import '@types/gapi';
import '@types/youtube';
```

## Custom Type Definitions
When including 3rd party modules you also need to include the type definition for the module
if they don't provide one within the module. You can try to install it with @types

```
npm install @types/node
npm install @types/lodash
```

If you can't find the type definition in the registry we can make an ambient definition in
this file for now. For example

```typescript
declare module "my-module" {
  export function doesSomething(value: string): string;
}
```


If you're prototyping and you will fix the types later you can also declare it as type any

```typescript
declare var assert: any;
declare var _: any;
declare var $: any;
```

If you're importing a module that uses Node.js modules which are CommonJS you need to import as

```typescript
import * as _ from 'lodash';```

