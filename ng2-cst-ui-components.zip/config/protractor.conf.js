//require('ts-node/register');
//var helpers = require('./helpers');

var HtmlScreenshotReporter = require('protractor-jasmine2-screenshot-reporter');
var JSONReporter = require('jasmine-json-test-reporter');

var reporter = new HtmlScreenshotReporter({
  dest: 'demo/e2e_reports/result_html',
  userCss: '../style/default.css',
  filename: 'index.html'
});

exports.config = {

  baseUrl: process.env.UI_APP_URL || 'http://localhost:3000',	
  framework: 'jasmine2',
  
  //ng12Hybrid: true,
  useAllAngular2AppRoots: true,
  
  allScriptsTimeout: 2000000000,
  
  seleniumAddress: process.env.SELENIUM_HUB_URL || 'http://localhost:4444/wd/hub',
  directConnect: !process.env.SELENIUM_HUB_URL,

  DASHBOARD_URL : process.env.UI_APP_URL || 'http://localhost:3000',

  specs: [   
              'demo/e2e/cst-textfield-e2e-spec.js',
              'demo/e2e/cst-textarea-test-spec.js',
              'demo/e2e/cst-dropdown-e2e-spec.js',
              'demo/e2e/cst-button-e2e-spec.js',
              'demo/e2e/cst-radiobutton-e2e-spec.js',
              'demo/e2e/cst-floating-menu-e2e-spec.js',
              'demo/e2e/cst-buttongroup-e2e-spec.js',
              'demo/e2e/cst-dialog-e2e-spec.js',
              'demo/e2e/cst-grid-e2e-spec.js',
              //'demo/e2e/cst-notification-e2e-spec.js',
          ],

	// use `npm run e2e`
  //specs: [
  //  helpers.root('src/**/**.e2e.ts'),
  //  helpers.root('src/**/*.e2e.ts')
  // ]
		  
  exclude: [],

  jasmineNodeOpts: {
    showTiming: true,
    showColors: true,
    isVerbose: false,
    includeStackTrace: true,
    defaultTimeoutInterval: 400000
  },

  //directConnect: false,

  capabilities: {
    'browserName': 'chrome'
  },

  /*  capabilities: {
    'browserName': 'chrome',
    'chromeOptions': {
      'args': ['show-fps-counter=true']
    }
  },*/


  // Setup the report before any tests start
   beforeLaunch: function() {
    return new Promise(function(resolve){
      reporter.beforeLaunch(resolve);
    });
  },

  // Assign the test reporter to each running instance
  onPrepare: function() {
    jasmine.getEnv().addReporter(reporter);
    jasmine.getEnv().addReporter(new JSONReporter({
        file: 'demo/e2e_reports/e2e-results.json',
        beautify: true,
        displayStacktrace: true,
        indentationLevel: 4 // used if beautify === true
    }));
  },

   // Close the report after all tests finish
   afterLaunch: function(exitCode) {
    return new Promise(function(resolve){
      reporter.afterLaunch(resolve.bind(this, exitCode));
    });
   }
}
