import { Component,	OnInit,	OnDestroy,	AfterViewInit } from '@angular/core';
import { Noticeable } from './helpers/Noticeable';
import { Notifier } from './helpers/Notifier';

@Component({
    selector: 'cst-notification',
    templateUrl: './cst-notification.component.html'
})


export class CSTNotificationComponent implements OnInit, OnDestroy, AfterViewInit, Noticeable {

    showNotification: boolean = false;
    state: any = {
        type: 'success', // Possible values success/warning/error/neutral
        title: 'NO-TITLE',
        message: null,
        buttons: [], // [{name: '<NAME OF BUTTON>', isPrimary:
        			// <true | false>, callBack: <function>}]
        showCloseButton: true,
        autoClose: false,
        showIcon: true
    };
    dialogClass: any = {
        success: false,
        error: false,
        neutral: false,
        warning: false,
        'no-message': false,
        'no-close-button': false
    };
    constructor() {
        this.showNotification = false;
        Notifier.getInstance().registerObserver(this);
    }

    ngOnInit(): void {
        console.log('CSTNotification::ngOnInit');
    }

    ngOnDestroy(): void {
        Notifier.getInstance().removeObserver(this);
    }

    ngAfterViewInit(): void {
        console.log('CSTDialog::ngAfterViewInit');
    }

    getDialogClass(): Object {
        this.dialogClass[this.state.type] = true;
        if (!this.state.showCloseButton) {
            this.dialogClass['no-close-button'] = true;
    }
        if (!this.state.message) {
            this.dialogClass['no-message'] = true;
    }
        if (this.state.message && this.state.buttons.length > 0) {
            this.dialogClass['no-close-button'] = true;
    }
        return this.dialogClass;
    }

    notify(message: Object): void {
        this.state = Object.assign({}, this.state, message);
        this.showNotification = true;
        if (!this.state.message) {
            this.state.buttons = [];
        }
        if (this.shouldHideIcon()) {
            this.state.showIcon = false;
        }
        if (this.shouldAutoCloseNotification()) {
            this.autoCloseNotification();
        }
    }

    autoCloseNotification(): void {
        window.setTimeout(() => this.onCloseDialog(), 5000);
    }

    buttonsAvailable(): boolean {
        return this.state.buttons.length > 0;
    }

    onCloseDialog(): void {
        this.showNotification = false;
        this.state = {
            type: 'success',
            title: 'NO-TITLE',
            message: null,
            buttons: [],
            showCloseButton: true,
            autoClose: false,
            showIcon: true
        };
        this.dialogClass = {
            success: false,
            error: false,
            neutral: false,
            warning: false,
           'no-message': false,
           'no-close-button': false
        };
    }

    close(): void {
        this.onCloseDialog();
    }

    shouldAutoCloseNotification(): boolean {
        return this.state.autoClose || (!this.buttonsAvailable() && !this.state.showCloseButton);
    }

    shouldHideIcon(): boolean {
        return !this.buttonsAvailable() && !this.state.message;
    }

}
