import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { Ng2PageScrollModule } from 'ng2-page-scroll';

import { CSTFloatingMenuComponent } from './cst-floating-menu.component';

@NgModule({
  imports: [CommonModule, Ng2PageScrollModule.forRoot()],
  declarations: [CSTFloatingMenuComponent],
  exports: [CSTFloatingMenuComponent]
})
export class CSTFloatingMenuModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTFloatingMenuModule, providers: []}; }
}
