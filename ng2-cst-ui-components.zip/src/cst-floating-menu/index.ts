export { CSTFloatingMenuComponent } from './cst-floating-menu.component';
export { CSTFloatingMenuModule } from './cst-floating-menu.module';
