import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { CSTButtonGroupComponent } from './cst-buttongroup.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

@NgModule({
  imports: [CommonModule, ButtonsModule],
  declarations: [CSTButtonGroupComponent],
  exports: [CSTButtonGroupComponent]
})
export class CSTButtonGroupModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTButtonGroupComponent, providers: []};
};
}
