import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'cst-buttongroup',
    templateUrl: './cst-buttongroup.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CSTButtonGroupComponent {

   @Input('id') _id: string = '';

   @Input('selection') _selection: string = 'multiple';

   @Input('disabled') _disabled: boolean = false;

   @Input('buttonitems') buttonitems: any = null;

   @Input('value') _value: any = null;

   @Output() selecteChange = new EventEmitter();

    selectedValueArray: string[] = [];

    _isvalidate: boolean = false;

    errorMsg: string = 'Please make selection';

    errorMsgShow: boolean = false ;

    buttonClass: Object = {
      'cst-button-small': false
    };

     buttonGroupClass: Object = {
      '.cst-buttongroup-error': false
    };

  @Input()
   get selectedValue(): any {
        return this.selectedValueArray;
    };

    set selectedValue(val: any) {
        this.selectedValueArray = val;
        this.selecteChange.emit(this.selectedValueArray);
    }

    get value(): any {
        return this._value;
    };

    set value(val: any) {
        this._value = val;
    }

    onClick(val): void {

       if (this._selection === 'single')
           {
               this.selectedValueArray.length = 0;
               this.selectedValueArray.push(val);
            }
        else{
            let valuePresent: boolean = false;
             this.selectedValueArray.forEach(item => {
                  if (item === val) {
                    valuePresent = true;
                    this.selectedValueArray.splice(this.selectedValueArray.indexOf(val), 1);
                  }
                });
              if (!valuePresent){
                this.selectedValueArray.push(val);
             }
        }
        this.displayErrorCss();
    }

    @Input()
    set smallButtonType(val: boolean) {
      if (val) {
        this.buttonClass['cst-button-small'] = val;
      }else{
        this.buttonClass['cst-button-small'] = val;
      }
    }

    @Input()
    set togglable(val: boolean){
      if (val){
        this._selection = 'single';
      }else{
        this._selection = 'multiple';
      }
    }

    @Input()
    set isvalidate(val: boolean){
      if (val){
       this._isvalidate = val;
       this.displayErrorCss();
     }
    }

    displayErrorCss(){
      if (this._isvalidate && this.selectedValueArray.length === 0){
          this.errorMsgShow = true ;
          this.buttonGroupClass['cst-buttongroup-error'] = true;
      }else{
        this.errorMsgShow = false ;
        this.buttonGroupClass['cst-buttongroup-error'] = false;
      }
    }
}
