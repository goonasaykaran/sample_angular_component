import { Component, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick, getTestBed, async }from '@angular/core/testing';
import { CSTDatePickerComponent } from './cst-datepicker.component';

let datepicker: CSTDatePickerComponent;

let focusedDate: Date = new Date(2010, 10, 10);

describe('\nUnit Test for CSTDatePickerComponent', () => {

describe('\n\tFor default Input properties', () => {

  beforeEach(async(() => {
      datepicker = new CSTDatePickerComponent();
    }));

 it('should be able to set value and gets updated', () => {
    // invokes the setter method of value
    datepicker.value = 'testValue';
    // verifies the value using the getter method of value
    expect(datepicker.value).toEqual('testValue');
  });

 it('should be able to set value and gets focusDate', () => {
    // invokes the setter method of value
    datepicker._focusedDate = focusedDate;
    // verifies the value using the getter method of value
    expect(datepicker._focusedDate).toEqual(focusedDate);
  });

 });
});
