import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MultiSelectModule } from '@progress/kendo-angular-dropdowns';

import { CSTMultiselectComponent } from './cst-multiselect.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';

@NgModule({
  imports: [CommonModule, MultiSelectModule, FormsModule, ReactiveFormsModule, BrowserModule, HttpModule],
  declarations: [CSTMultiselectComponent],
  exports: [CSTMultiselectComponent]
})
export class CSTMultiselectModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTMultiselectModule, providers: []};
};
}
