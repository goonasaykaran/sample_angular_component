import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { CSTTooltipComponent } from './cst-tooltip.component';

@NgModule({
  imports: [CommonModule],
  declarations: [CSTTooltipComponent],
  exports: [CSTTooltipComponent]
})
export class CSTTooltipModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTTooltipModule, providers: []};
};
}
