import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTTooltipComponent } from './cst-tooltip.component';

// @Inputs.........................................................

let cstTooltipElement: CSTTooltipComponent;

describe('\nUnit Tests for CSTTooltipComponent', () => {
  describe('\n\tFor default input', () => {

    beforeEach(() => {
        cstTooltipElement = new CSTTooltipComponent();
     });

     it('should have empty tooltip message ', () => {
         expect(cstTooltipElement._message).toBe('');
     });

     it('should show tooltip', () => {
         expect(cstTooltipElement.showToolTip).toBe(true);
     });

     it('should have display-none tooltipClass ', () => {
        expect(cstTooltipElement.toolTipClass).toEqual('display-none');
     });

     it('should be medium tooltipType ', () => {
        expect(cstTooltipElement._tooltipType).toEqual('medium');
     });

  });

  // @Methods................................................
  describe('\n\tFor methods and functions', function() {

    beforeEach(() => {
        cstTooltipElement = new CSTTooltipComponent();
    });

    it('should log console message on init call', () => {

      cstTooltipElement._message = 'MyToolTip';
      spyOn(console, 'log');
      cstTooltipElement.ngOnInit(); // invokes the method to be tested
      // verifications
      expect(console.log).toHaveBeenCalled();
      expect((<any>console).log.calls.count()).toBe(1);
    });

    it('should able to set and get Tooltip message', () => {
      // invokes the setter method of message
      cstTooltipElement.tooltip = 'tooltip message';
      // verifies the message using the getter method of value
      expect(cstTooltipElement.tooltip).toEqual('tooltip message');
    });

    it('should able to set tooltiptype', () => {
      // invokes the setter method of tooltipType
      cstTooltipElement.tooltipType = 'tooltipType';
      // verifies the message using the getter method of value
      expect(cstTooltipElement._tooltipType).toEqual('tooltipType');
    });

    it('should onClickToolTip event with showToolTip true', () => {
      let fakeEventObject: Object ;

      cstTooltipElement.showToolTip = true;
      cstTooltipElement.onClickToolTip(fakeEventObject);

      expect(cstTooltipElement.toolTipClass).toEqual('display-block');
      expect(cstTooltipElement.showToolTip).toEqual(false);
    });

    it('should onClickToolTip event with showToolTip false', () => {
        let fakeEventObject: Object ;

        cstTooltipElement.showToolTip = false;
        cstTooltipElement.onClickToolTip(fakeEventObject);

        expect(cstTooltipElement.toolTipClass).toEqual('display-none');
        expect(cstTooltipElement.showToolTip).toEqual(true);
     });
  });
});

