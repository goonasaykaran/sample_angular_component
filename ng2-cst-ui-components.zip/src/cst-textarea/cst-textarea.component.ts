import { Component, Input, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

const noop: any = () => {
	// nothing here
};
export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide : NG_VALUE_ACCESSOR,
    useExisting: forwardRef( () => CSTTextareaComponent),
    multi: true
};

@Component({

    selector: 'cst-textarea',
    templateUrl: './cst-textarea.component.html',
    providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class CSTTextareaComponent implements ControlValueAccessor {

    @Input('type') type: string = 'text';
    @Input('label') label: string;
    @Input('tooltip') tooltipMsg: string = null;
    @Input('tooltipType') _tooltipType: string = null;
    @Input('placeholder') placeholder: string = '';
    @Input('disabled') disabled: boolean = false;
    @Input('isRequired') isRequired: boolean = false;
    @Input('showValueChange') showValueChange: boolean = false;
    @Input('rows') rows: number;
    @Input('cols') cols: number;

    _resize: boolean = false;

    // Property changed from private to public
    public onTouchedCallback: () => void = noop;

    public onChangeCallback: (_: any) => void = noop;

    private innerValue: any = '';
    private previousValue: any = '';

    constructor() {
       console.log('cst.textarea.component');
    }

    ngOnInit(): void {
       console.log('textarea component inited');
    }

    @Input()
    set resize(newValue: any) {
        this._resize = newValue;
    };

    get resize(): any {
        if (this._resize) {
            return 'true';
        } else {
            return 'none';
        }
    };

    get isValueChanged(): boolean {
       return (this.showValueChange && this.innerValue && (this.innerValue !== this.previousValue));
    }

    get value(): any {
        return this.innerValue;
    };

    set value(v: any) {
        if (v !== this.innerValue) {
            this.previousValue = this.innerValue;
            this.innerValue = v;
            this.onChangeCallback(v);
        }
    }

    onBlur(): void {
    this.onTouchedCallback();
    }

    writeValue(value: any): void {
        if (value !== this.innerValue) {
        this.innerValue = value;
			// this.value=value;
        }
    }

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }
}
