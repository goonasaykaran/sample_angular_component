import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { CSTTextareaComponent } from './cst-textarea.component';
import { CSTTooltipModule } from '../cst-tooltip/cst-tooltip.module';

@NgModule({
  imports: [CommonModule, CSTTooltipModule, BrowserModule, FormsModule],
  declarations: [CSTTextareaComponent],
  exports: [CSTTextareaComponent]
})
export class CSTTextareaModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTTextareaModule, providers: []}; }
}
