import { TestBed } from '@angular/core/testing';
import { CSTDialog } from './cst-dialog.component';


let dialog: CSTDialog;
// Passing Button type objects to state Array
 let state: Array<Object> = [{name: 'Back',
                                    action: () => console.log('hello button 1')}, // Button object 1
                            {name: 'Proceed',
                                   action: () => console.log('hello button 2')}]; // Button object 2

describe('\nUnit Tests for CSTDialogComponent', () => {
describe('\n\tFor default Input properties', () => {

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ CSTDialog ]
    });
        dialog = new CSTDialog();
});


it('should be able to set and get value', () => {
dialog.buttons = state;
expect(dialog.buttons).toEqual(state);

});

it('should be able to create instance', () => {
    expect(dialog instanceof CSTDialog).toBe(true);

});

it('should be able to set and get title', () => {
    dialog.title = 'My Title';
    expect(dialog.title).toEqual('My Title');

});

it('should be visible to true', () => {
    dialog.visible = true;
    expect(dialog.visible).toBeTruthy();

});
});

describe('\n\tFor methods and functions', () => {

    beforeEach(() => {
        TestBed.configureTestingModule({
        providers: [ CSTDialog ]
    });
    dialog = new CSTDialog();
});

it('should have buttons', () => {
    expect(dialog.buttonsAvailable()).toEqual(false);
});
});
});
