import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { CSTDialog } from './cst-dialog.component';
import { CSTButtonModule } from '../cst-button/cst-button.module';

@NgModule({
  imports: [CommonModule, CSTButtonModule],
  declarations: [CSTDialog],
  exports: [CSTDialog]
})
export class CSTDialogModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTDialogModule, providers: []};
};
}
