import {
    Component,
    Input,
    ChangeDetectionStrategy
} from '@angular/core';
/*
 * We're loading this component asynchronously
 * We are using some magic with es6-promise-loader that will wrap the module with a Promise
 * see https://github.com/gdi2290/es6-promise-loader for more info
 */
@Component({
    selector: 'cst-button',
    templateUrl: './cst-button.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CSTButtonComponent {
  buttonClass: Object = {
    'cst-button-small': false,
    'cst-button-align-left': false,
    'cst-button-align-right': true
};
buttonTypeClass: string = '';

    /**
     * @property _id
     * Sets the id state of the component.
     */
@Input('id')
_id: string = '';

    /**
     * @property _name
     * Sets the name state of the component.
     */
@Input('name')
_name: string = '';

    /**
     * @property _disabled
     * Sets the disabled state of the component.
     */
@Input('disabled')
_disabled: boolean = false;

	/*
      @property _class
     */
@Input('class')
_class: string = '';

    /**
     * @property _primary
     * Sets the primary state of the component.
     */
@Input('primary')
_primary: boolean = false;

    /**
     * @property _icon
     * Sets the icon state of the component.
     */
@Input('icon')
_icon: string = '';

    /**
     * @property _iconClass
     * Sets the iconClass state of the component.
     */
@Input('iconClass')
_iconClass: string = '';

    /**
     * @property _imageUrl
     * Sets the imageUrl state of the component.
     */
@Input('imageUrl')
_imageUrl: string = '';

    /**
     * @property _togglable
     * Sets the togglable state of the component.
     */
@Input('togglable')
_togglable: boolean = false;

    /**
     * @property _value
     * Sets the value of the button.
     */
@Input('value')
_value: any = null;

    /**
     * @property _size
     * Sets the size of the button.
     */
@Input()
set buttonType(val: any) {
  if (val) {
    this.buttonClass['cst-button-small'] = val;
  }
}

@Input()
set align(val: any) {
    this.buttonClass['cst-button-align-left'] = val === 'left';
    this.buttonClass['cst-button-align-right'] = val !== 'left';
}

constructor() {
		// constructor
}

ngOnInit(): void {
  console.log('button component inited');
}
}
