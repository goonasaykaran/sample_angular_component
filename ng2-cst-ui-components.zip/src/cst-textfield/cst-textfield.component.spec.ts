
import { Component } from '@angular/core';
import { ComponentFixture, inject, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CSTTextfieldComponent } from './cst-textfield.component';


let textfield: CSTTextfieldComponent;

describe('\nUnit Tests for CSTTextField Component',  () => {

describe('\n\tFor Input default properties',  () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ CSTTextfieldComponent ]
    });
    textfield = new CSTTextfieldComponent();
  });

  it('should be \'text\' type only', () => {
    expect(textfield.type).toEqual('text');
  });


  it('should have lable with undefined', () => {
    expect(textfield.label).toEqual(undefined);
  });

  it('should have null tooltipMsg', () => {
    expect(textfield.tooltipMsg).toBe(null);
  });


  it('should have empty placeholder ', () => {
    expect(textfield.placeholder).toBe('');
  });


  it('should not be disabled', () => {
    expect(textfield.disabled).toBe(false);
  });


  it('should not be a mandatory field', () => {
    expect(textfield.isRequired).toBe(false);
  });


  it('should show value change ', () => {
    expect(textfield.showValueChange).toBe(false);
  });

 it('should check errorMsg', () => {
    expect(textfield.errorMsg).toEqual('Oops! Something is wrong...');
  });

 it('should check validationClass', () => {
    expect(textfield.validationClass).toEqual('');
  });

  it('should show errorMsg', () => {
    expect(textfield.errorMsgShow).toBe(false);
  });

});


describe('\n\tFor methods and functions',  () => {

 beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ CSTTextfieldComponent ]
    });
    textfield = new CSTTextfieldComponent();
  });


 it('should log console message on init call', () => {
    spyOn(console, 'log');
    textfield.ngOnInit(); // invokes the method to be tested
    // verifications
    expect(console.log).toHaveBeenCalled();
    expect((<any>console).log.calls.count()).toBe(2);
  });

 it('should log console message on ngOnDestroy call', () => {
    spyOn(console, 'log');
    textfield.ngOnDestroy(); // invokes the method to be tested
    // verifications
    expect(console.log).toHaveBeenCalled();
    expect((<any>console).log.calls.count()).toBe(1);
  });

  it('should log console message on ngAfterViewInit call', () => {
    spyOn(console, 'log');
    textfield.ngAfterViewInit(); // invokes the method to be tested
    // verifications
    expect(console.log).toHaveBeenCalled();
    expect((<any>console).log.calls.count()).toBe(1);
  });

  it('should change the value', () => {
    textfield.showValueChange = true;
    let innerValue = 'TextFieldInnervalue';
    textfield.value = 'TextFieldValue';
    expect(textfield.value).toEqual('TextFieldValue');
    expect(textfield.isValueChanged).toEqual(true);
  });


  it('should set and get the value', () => {

    // invokes the setter method of value
    let innerValue = 'TextFieldInnervalue';
    textfield.value = 'TextFieldValue';
    // verifies the value using the getter method of value
    expect(textfield.value).toEqual('TextFieldValue');
  });


  it('should invoke onChangeCallback() by set value', () => {

    // mocks the call to onChangeCallback
    spyOn(textfield, 'onChangeCallback').and.callFake(function() {
      return;
    });
    // invokes the method to be tested
    textfield.value = 'text';
    // verifications
    expect(textfield.onChangeCallback).toHaveBeenCalled();
    expect((<any>textfield).onChangeCallback.calls.count()).toBe(1);
  });


  it('should invoke onTouchCallback() by onBlur()', () => {  // @ Hamzeen

    // mocks the call to onTouchedCallback
    spyOn(textfield, 'onTouchedCallback').and.callFake(function() {
      return;
    });
    // invokes the method to be tested
    textfield.onBlur();
    // verifications
    expect(textfield.onTouchedCallback).toHaveBeenCalled();
    expect((<any>textfield).onTouchedCallback.calls.count()).toBe(1);
  });


  it('should set expected value for \'validationClass\' by onInput()', () => {   // @ Hamzeen

    textfield.onInput();
    expect(textfield.validationClass).toEqual('validate');
  });

   it('should set showErrorMsg', () => {

    // invokes the setter method of value
     textfield.showErrorMsg = false;
    // verifies the value using the getter method of value
    expect(textfield.errorMsgShow).toEqual(false);
    expect(textfield.textFieldClass['cst-textfield-error']).toEqual(false);
  });


  it('should change value while invoking Writevalue', () => {
    let innerValue = 'TextFieldInnervalue';
    textfield.writeValue ('TextFieldValue');
    expect(textfield.value).toEqual('TextFieldValue');
  });


  it('should test registerOnChange', () => {

    let fakeFunction = function() {
      return;
    };
    textfield.registerOnChange(fakeFunction);
    expect(textfield.onChangeCallback).toEqual(fakeFunction);
  });


  it('should test registerOnTouched', () => {

    let fakeFunction = function() {
      return;
    };
    textfield.registerOnTouched(fakeFunction);
    expect(textfield.onTouchedCallback).toEqual(fakeFunction);
  });
 });
});


