import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CSTTooltipModule } from '../cst-tooltip/cst-tooltip.module';

import { CSTRadioButtonComponent } from './cst-radiobutton.component';

@NgModule({
  imports: [CommonModule, CSTTooltipModule],
  declarations: [CSTRadioButtonComponent],
  exports: [CSTRadioButtonComponent]
})
export class CSTRadioButtonModule {
    public static forRoot(): ModuleWithProviders
                             {return {ngModule: CSTRadioButtonModule, providers: []};
                         };
}
