import { Component, ElementRef, Input, forwardRef, Output, Inject,
         OnInit, OnDestroy, AfterViewInit, EventEmitter } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import _ from 'lodash';

const noop: any = () => {
	// nothing here
};
export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide : NG_VALUE_ACCESSOR,
    useExisting: forwardRef( () => CSTRadioButtonComponent),
    multi: true
};
@Component({
    selector: 'cst-radiobutton',
    templateUrl: './cst-radiobutton.component.html'
})
export class CSTRadioButtonComponent implements ControlValueAccessor,
                                                OnInit, OnDestroy, AfterViewInit {
    @Output() change: EventEmitter<any> = new EventEmitter();
    @Input() bindModelData: any;
    @Input() guid: string;
    @Output() bindModelDataChange: any = new EventEmitter();
    @Input('value') _value: any = null;

    previousValue: string = null;
    currentValue: string = null;
    radiButtonColumnClass: string = '';

    // Property changed from private to public
    public onTouchedCallback: () => void = noop;

    public onChangeCallback: (_: any) => void = noop;

  /**
   * @property label
   * provides a label/title to component
   */
    @Input()
    label: string;

  /**
   * @property showpreviousvalue
   * Flags weather to show previous value as small line of text below when it changes the state
   */
    @Input()
    showpreviousvalue: boolean = false;

  /**
   * ======TOOLTIP PROPERTIES======
   * -----------------------------------------------
   */

  /**
   * @property tooltip
   * Tooltip message
   */
    @Input('tooltip')
    tooltipMessage: string = null;

  /**
   * @property options
   * Radio button Options
   */
    @Input('options')
    options: Array<{text: string, value: string}>;
  /**
   * @property options
   * Radio button view type 'column' or 'row'
   */
    @Input('viewType')
    viewType: string = 'column';

  /**
   * ======DEFAULT PROPERTIES FROM KENDO DropDownList======
   * ------------------------------------------------------------------------
   */

  /**
   * @property _text
   * Sets the text in textarea
   */
    @Input('text')
    _text: string;

  /**
   * @property _autofocus
   * Specifies that a text area should automatically get focus when the page loads
   */
    @Input('autofocus')
    _autofocus: boolean= false;

  /**
   * @property _disabled
   * Specifies that a text area should be disabled
   */
    @Input('disabled')
    _disabled: boolean = false;

  /**
   * @property _checked
   * Specifies that a radiobutton should be checked
   */
    @Input('checked')
    _checked: boolean = false;

  /**
   * @property _defaultChecked
   * Specifies that a radiobutton should be defaultChecked
   */
    @Input('defaultChecked')
    _defaultChecked: boolean = false;

  /**
   * @property _form
   * Specifies one or more forms the text area belongs to
   */
    @Input('form')
    _form: string;

  /**
   * @property _name
   * 	Specifies a name for a text area
   */
    @Input('name')
    _name: string;

  /**
   * @property _required
   * Specifies that a text area is required/must be filled out
   */
    @Input('required')
    _required: boolean = false;

     constructor(@Inject(ElementRef) elementRef: ElementRef) {
    // super(elementRef);
    }

    getGUID(): any {
    // this.guid = this.guid || ('ui' + _.uniqueId());
        return 'ui303';
    }

    onChange(event: any): void {
    /*let value: any = event.target.value;
    event.stopPropagation();
    this.setChangedValue(value);
    event.data = value;*/
    }

    updateData(newVal: any): void {
    /*this.bindModelData = newVal;
    this.bindModelDataChange.emit(newVal);
    this.change.next(newVal);*/
    }

    setColumnWidth(): void {
        if (this.viewType === 'column') {
            let optionsLength: number = this.options.length;
                if (optionsLength <= 6) {
                let gridLength: number = 12;
                let columnWidth: number = Math.floor(gridLength / optionsLength);
                this.radiButtonColumnClass = 'col-md-' + columnWidth + ' col-sm-' + columnWidth;
            }
        }
    }

    ngOnInit(): void {
        this.setColumnWidth();
        this.updateData(this._value);
		// super.ngOnInit();
    }

    ngOnDestroy(): void {
		// super.ngOnDestroy();
    }

    ngAfterViewInit(): void {
		// super.ngAfterViewInit();
    }

    setChangedValue(val: any): void {
        if (this.currentValue) {
            this.previousValue = this.currentValue;
            this.currentValue = val;
        } else {
        this.currentValue = val;
        }
    }

	/*getGUID(): any {
		this.guid = this.guid || ('ui' + _.uniqueId());
		return this.guid;
	}*/

    setSelectedValue(val: any): void {
        this._value = val;
    }

  /**
   * ControlvalueAccessor interface
   */
    writeValue(value: any): void {
        if (value) {
            this._value = value;
            this.setSelectedValue(value);
        }
    }

    registerOnChange(fn: any): void {
        this.onChangeCallback = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouchedCallback = fn;
    }
}
