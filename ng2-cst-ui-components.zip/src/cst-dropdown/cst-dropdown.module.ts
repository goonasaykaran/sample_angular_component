import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { CSTTooltipModule } from '../cst-tooltip/cst-tooltip.module';

import { CSTDropdownComponent } from './cst-dropdown.component';

@NgModule({
  imports: [CommonModule, CSTTooltipModule],
  declarations: [CSTDropdownComponent],
  exports: [CSTDropdownComponent]
})
export class CSTDropdownModule {
  public static forRoot(): ModuleWithProviders
         {return {ngModule: CSTDropdownModule, providers: []};
};
}
