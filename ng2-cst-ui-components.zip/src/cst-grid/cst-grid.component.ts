import { Component, Input } from '@angular/core';
import * as _ from 'underscore';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
    selector: 'cst-grid',
    templateUrl: './cst-grid.component.html'
})
export class CSTGridComponent {
    @Input() gridData: any;
    @Input() gridColumns: any;

    private selectFilter: any = {};
    private inputFilter: any = {};

    private domSanitizer: DomSanitizer;

    constructor(ds: DomSanitizer) {
        this.domSanitizer = ds;
    }

    filterText(_selectFilter, arg) {

      this.selectFilter[arg] = _selectFilter;
      this.selectFilter = _.clone(this.selectFilter );
    }

    getSanitisedHTML(unsafeHtml): any {
        return this.domSanitizer.bypassSecurityTrustHtml(unsafeHtml);
    }
}
