import { NgModule, ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { GridModule } from '@progress/kendo-angular-grid';
import { FormsModule } from '@angular/forms';

import { CSTGridComponent } from './cst-grid.component';
import { FilterPipe } from './cst-grid.filter.pipe';
import { CSTTooltipModule } from '../cst-tooltip/cst-tooltip.module';

@NgModule({
  imports: [CSTTooltipModule, BrowserModule, GridModule, FormsModule],
  declarations: [CSTGridComponent, FilterPipe],
  exports: [CSTGridComponent, FilterPipe]
})
export class CSTGridModule {
  public static forRoot(): ModuleWithProviders {return {ngModule: CSTGridModule, providers: []}; }
}
