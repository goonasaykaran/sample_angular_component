describe('\t\tTests for CSTButton Component', () => {
    "use strict";
    /*var disabled_button_1 = element(by.css('cst-button [id="myButton01"]'));
    var disabled_button_2 = element(by.css('cst-button [id="myButton02"]'));
    var primary_button = element(by.css('cst-button [name="Primary"]'));
    var cancel_button = element(by.css('cst-button [name="Cancel"]'));*/

    var btn_ctx_menu = element(by.id('float_menu'));
    var elements = element.all(protractor.By.css('.menu .showMenu'));
    
    var disabled_button = element(by.css('cst-button [id="myButton_01"]'));
    var primary_button_1 = element(by.css('cst-button [id="myButton_02"]'));
    var secondary_button = element(by.css('cst-button [id="myButton_03"]'));
    var primary_button_2 = element(by.css('cst-button [id="myButton_04"]'));
   
    it('Should hover the mouse over floating menu', () => {

    console.log('\t1.Hovering the mouse over floating menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);

    console.log("\t2.Clicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() { 
    browser.driver.sleep(1000);
    
    console.log("\t3.Clicking the CST Button in the floating menu items")
    elements.get(3).click().then(function() {
      browser.driver.sleep(1000); 
    }, 120);
  })) 
});

    it('Should hover the mouse arrow over Disabled button',() => {

    console.log('\tHovering the mouse over Disabled button');
    browser.actions().mouseMove(disabled_button).perform();
    browser.driver.sleep(3000); //timeout to check the above operation with naked eye!
    
 });

   it('Should hover the mouse arrow and hold mouse click over primary_button_1', () => { 

    console.log('\tHovering the mouse over primary_button');
    browser.actions().mouseMove(primary_button_1).perform();
    browser.driver.sleep(3000); //timeout to check the above operation with naked eye!
    console.log('\tClicking on the primary_button');
   
    browser.actions().mouseDown(primary_button_1).perform();
    browser.sleep(3000); //timeout to check the above operation with naked eye!
    browser.actions().mouseUp(primary_button_1).perform();
  });

   it('Should hover the mouse arrow and hold mouse click over secondary_button', () => { 

    console.log('\tHovering the mouse over primary_button');
    browser.actions().mouseMove(secondary_button).perform();
    browser.driver.sleep(3000); //timeout to check the above operation with naked eye!
    console.log('\tClicking on the primary_button');
   
    browser.actions().mouseDown(secondary_button).perform();
    browser.sleep(3000); //timeout to check the above operation with naked eye!
    browser.actions().mouseUp(secondary_button).perform();
  });

   it('Should hover the mouse arrow and hold mouse click over primary_button_2', () => { 

    console.log('\tHovering the mouse over primary_button');
    browser.actions().mouseMove(primary_button_2).perform();
    browser.driver.sleep(3000); //timeout to check the above operation with naked eye!
    console.log('\tClicking on the primary_button');
   
    browser.actions().mouseDown(primary_button_2).perform();
    browser.sleep(3000); //timeout to check the above operation with naked eye!
    browser.actions().mouseUp(primary_button_2).perform();
  });
});



  /*it('Should hover the mouse arrow over Disabled button 1',() => {

    console.log('\tHovering the mouse over Disabled button 1');
    browser.actions().mouseMove(disabled_button_1).perform();
    browser.driver.sleep(3000); //timeout to check the above operation with naked eye!
    
 });

  it('Should hover the mouse arrow over Disabled button 2', () =>{

    console.log('\tHovering the mouse over Disabled button 2');
    browser.actions().mouseMove(disabled_button_2).perform();
    browser.driver.sleep(3000); //timeout to check the above operation with naked eye!

});

   it('Should hover the mouse arrow and hold mouse click over Primary button', () => { 

    console.log('\tHovering the mouse over Primary button');
    browser.actions().mouseMove(primary_button).perform();
    browser.driver.sleep(5000); //timeout to check the above operation with naked eye!
    console.log('\tClicking on the Primary button');
   
    browser.actions().mouseDown(primary_button).perform();
    browser.sleep(3000); //timeout to check the above operation with naked eye!
    browser.actions().mouseUp(primary_button).perform();

});
   
   it('Should hover the mouse arrow and hold mouse click over Cancel button', () => {

    console.log('\tHovering the mouse over Cancel button');
    browser.actions().mouseMove(cancel_button).perform();
    browser.driver.sleep(5000); //timeout to check the above operation with naked eye!
    console.log('\tClicking on the Cancel button');
  
    browser.actions().mouseDown(cancel_button).perform();
    browser.sleep(3000); //timeout to check the above operation with naked eye!
    browser.actions().mouseUp(cancel_button).perform();
 });

    it('Should test the change in color of text when mouse is hovered over CSTButton', () => {

      function waitForCssValue (elementFinder, cssProperty, cssValue) {
        return function () {
          return elementFinder.getCssValue(cssProperty).then(function(actualValue) {
            return actualValue === cssValue;
        });
    };
   };

    console.log('\tChecking the change in color of text for Disabled button 1')
      expect(disabled_button_1.getCssValue("color")).toEqual("rgba(136, 136, 136, 1)");
      browser.actions().mouseMove(disabled_button_1).perform();
      browser.driver.sleep(5000); //timeout to check the above operation with naked eye!
      browser.wait(waitForCssValue(disabled_button_1, "color", "rgba(136, 136, 136, 1)"), 2000);
  

    console.log('\tChecking the change in color of text for Disabled button 2')
      expect(disabled_button_2.getCssValue("color")).toEqual("rgba(136, 136, 136, 1)");
      browser.actions().mouseMove(disabled_button_2).perform();
      browser.driver.sleep(5000); //timeout to check the above operation with naked eye!
      browser.wait(waitForCssValue(disabled_button_2, "color", "rgba(136, 136, 136, 1)"), 2000);


    console.log('\tChecking the change in color of text for Primary button')
      expect(primary_button.getCssValue("color")).toEqual("rgba(255, 255, 255, 1)");
      browser.actions().mouseMove(primary_button).perform();
      browser.driver.sleep(5000); //timeout to check the above operation with naked eye!
      browser.wait(waitForCssValue(primary_button, "color", "rgba(255, 255, 255, 1)"), 2000);


    console.log('\tChecking the change in color of text for Cancel button')
      expect(cancel_button.getCssValue("color")).toEqual("rgba(102, 99, 99, 1)");
      browser.actions().mouseMove(cancel_button).perform();
      browser.driver.sleep(5000); //timeout to check the above operation with naked eye!
      browser.wait(waitForCssValue(cancel_button, "color", "rgba(102, 99, 99, 1)"), 2000);

      browser.driver.sleep(3000);

    }); */
