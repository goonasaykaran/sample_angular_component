describe('\t\tTests for Notification Component', () => {
  "use strict";

  var cst_button_sucess= element(by.css('cst-button [name="Success"]')); 
    
  var cst_button_error= element(by.css('cst-button [name="Error"]')); 
  var cst_button_warning= element(by.css('cst-button [name="Warning"]')); 
  var cst_button_neutral= element(by.css('cst-button [name="Neutral"]')); 
  var cst_button_without= element(by.css('cst-button [name="Without Buttons"]')); 
  var cst_button_without_and_message= element(by.css('cst-button [name="Without buttons & message"]')); 
  var cst_button_without_and_message_close= element(by.css('cst-button [name="Without buttons, message & close"]')); 

  var cst_notification_sucess = element (by.css('cst-notification [name="Proceed"]'));
  var cst_notification_ignore = element (by.css('cst-notification [name="Ignore"]'));
  var cst_notification_close = element (by.css('cst-notification .k-icon'));
  var cst_notification_popup= element(by.css('cst-notification .cst-notification-component-wrapper'));

  browser.get('http://10.91.95.45:8080', 18000000);

 it('should show sucess Notification after click on sucess button ', () => {
 
  console.log("\n\tShould show success Notification after click on success button ");
    cst_button_sucess.click();
    expect(cst_notification_popup.isPresent()).toEqual(true);
    browser.driver.sleep(5000); 
    cst_notification_sucess.click(); 
    browser.driver.sleep(5000);
  });

 it('should hover on Proceed and Ignor button on notification  ', () => {
 
  console.log("\n\tShould hover on Proceed and Ignore button in notification window ");

  console.log("\n\t\t 1.0 Open Success notification popup");
  cst_button_sucess.click();
  expect(cst_notification_popup.isPresent()).toEqual(true);
  console.log("\n\t\t 2.0 Hover over Proceed button ");
  browser.actions().mouseMove(cst_notification_sucess).perform();
  browser.driver.sleep(3000);
  console.log("\n\t\t 3.0 Hover over Ignore button ");
  browser.actions().mouseMove(cst_notification_ignore).perform();
  browser.driver.sleep(3000); 
  cst_notification_sucess.click(); 
  browser.driver.sleep(5000);
  });

 it('should show Error Notification after click on Error button ', () => {
    console.log("\n\tShould show Error Notification after click on Error button");
    cst_button_error.click();
    browser.driver.sleep(5000);
    expect(cst_notification_popup.isPresent()).toEqual(true);
    cst_notification_sucess.click();
    browser.driver.sleep(5000);       
  });


 it('should show Warning Notification after click on Warning button ', () => {
  console.log("\n\tShould show Warning Notification after click on Warning button");
    cst_button_warning.click();
    expect(cst_notification_popup.isPresent()).toEqual(true);
    browser.driver.sleep(5000); 
    cst_notification_sucess.click(); 
    browser.driver.sleep(5000);
  });


it('should show Neutral Notification after click on Neutral button ', () => {
    console.log("\n\tShould show Neutral Notification after click on Neutral button ");
    cst_button_neutral.click();
    expect(cst_notification_popup.isPresent()).toEqual(true);
    browser.driver.sleep(5000);
    cst_notification_sucess.click(); 
    browser.driver.sleep(5000);  
  });

it('should show Without Buttons Notification after click on Without Buttons', () => {
    console.log("\n\tShould show Without Buttons Notification after click on Without Buttons");
    cst_button_without.click();
    expect(cst_notification_popup.isPresent()).toEqual(true);
    browser.driver.sleep(5000); 
    cst_notification_close.click(); 
    browser.driver.sleep(5000);  
  });

it('should show Without Buttons  and Message Notification after click on Without Buttons and Message', () => {
    console.log("\n\tShould show Without Buttons and Message Notification after click on Without Buttons");
    cst_button_without_and_message.click();
    expect(cst_notification_popup.isPresent()).toEqual(true);
    browser.driver.sleep(5000);   
    cst_notification_close.click(); 
    browser.driver.sleep(5000);  
  });

it('should show Without Buttons, Message and Close Notification after click on Without Buttons, Message and Close ', () => {
    console.log("\n\tShould show Without Buttons, Message and Close  Notification after click on Without Buttons, Message and Close ");
    cst_button_without_and_message_close.click();
    browser.driver.sleep(5000); 
  });

});