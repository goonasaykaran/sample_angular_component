describe('UI Automation Tests: CSTTextArea component', function() {
  "use strict";
   

  describe('UI Automation Tests: CSTTextArea component_01', function() {
   
   let csttextarea_01 = element(by.css('cst-textarea [ placeholder="Placeholder Textarea 1."]'));
   let input_tooltip_01 = element(by.css('#dashboard_csttextarea_01 div div label cst-tooltip span div.tooltip-icon'));
   
   var btn_ctx_menu = element(by.id('float_menu'));
   var elements = element.all(protractor.By.css('.menu .showMenu'));
  
it('Should hover the mouse over float menu', () => {

    console.log('\t Hovering the mouse on float menu');
    browser.actions().mouseMove(btn_ctx_menu).perform();
    browser.driver.sleep(3000);
    console.log("\tClicking over the context menu");
    browser.wait(btn_ctx_menu.click().then(function() {
    browser.driver.sleep(3000);  
    console.log('\tClicking over the textarea');
    elements.get(1).click().then(function() {
        browser.driver.sleep(3000); 
     },120);
    }))
 }); 

it('should click on the text area',() => {
    console.log("\t1.0. should click on the text area");
    browser.wait(csttextarea_01.click().then(function() { 
        browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
    }),3000);
 });

it('should send key into text area and clear key',() => {
    console.log("\t2.0. should send key into text area and clear key");
 
   'SendandClear-Key-Test'.split('').forEach((c) => csttextarea_01.sendKeys(c));
 
    browser.driver.sleep(3000);
    csttextarea_01.clear();
    browser.driver.sleep(3000);
});

it('should send key in multiple lines into text area',() => {
 
    console.log("\t3.0. should send key in multiple lines into text area");
   'Send-Key-Test-Line 01'.split('').forEach((c) => csttextarea_01.sendKeys(c));
    csttextarea_01.sendKeys(protractor.Key.ENTER);
    browser.driver.sleep(2000);
    'Send-Key-Test-Line 02'.split('').forEach((c) => csttextarea_01.sendKeys(c));
    csttextarea_01.sendKeys(protractor.Key.ENTER);
    browser.driver.sleep(2000);
    'Send-Key-Test-Line 03'.split('').forEach((c) => csttextarea_01.sendKeys(c));
    browser.driver.sleep(3000);
    csttextarea_01.clear();
});

it('should select and unselect text', () => {
  
    console.log("\t4.0. should select text and unselect text");
    csttextarea_01.clear();
    browser.driver.sleep(3000);
    csttextarea_01.click();
    browser.driver.sleep(3000);
    'Select-Text-Test'.split('').forEach((c) => csttextarea_01.sendKeys(c));
    browser.driver.sleep(3000);
    csttextarea_01.sendKeys(protractor.Key.CONTROL, "a");
    browser.driver.sleep(3000);  

    var highlightedText = browser.executeScript(function getSelectionText()       
      {         
         return window.getSelection().toString(); 
      });
    expect(highlightedText).toEqual('Select-Text-Test');
    browser.driver.sleep(3000); 
    csttextarea_01.click();
    browser.driver.sleep(3000); 
    csttextarea_01.clear();
  });

it('should delete the text', () => {
   
    console.log("\t5.0. should delete the text"); 
    csttextarea_01.clear();
    'Back-Space-Test'.split('').forEach((c) => csttextarea_01.sendKeys(c));

    csttextarea_01.getAttribute('value').then(function(inputValue) {
       expect(inputValue).toEqual('Back-Space-Test');
    });

    csttextarea_01.sendKeys(protractor.Key.BACK_SPACE);
    browser.driver.sleep(1000);

    csttextarea_01.getAttribute('value').then(function(inputValue) {
      expect(inputValue).toEqual('Back-Space-Tes');
    });
 
  for (let i = 0; i < 4; i++) { 
        browser.driver.sleep(1000);
        csttextarea_01.sendKeys(protractor.Key.BACK_SPACE);
      } 
    csttextarea_01.clear();
  });

it('should click/unclick the Tooltip ', () => {

    console.log("\t6.0. should click/unclick the Tooltip of textarea_01"); 
 
    browser.actions().mouseMove(csttextarea_01).perform();
    browser.driver.sleep(3000);

    browser.wait(input_tooltip_01.click().then(function() { 
      browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
    }),3000);
    browser.driver.sleep(3000)
    input_tooltip_01.click();
    browser.driver.sleep(3000)
});

 it('should resize the text area ', () => {

    console.log("\t7.0. should resize the text area "); 
    csttextarea_01.getSize().then(function(result){ 
    browser.sleep(3000);
    browser.driver.actions().mouseMove(csttextarea_01, {x: result.width-2, y: result.height-2})
      .mouseDown()
      .mouseMove(csttextarea_01, {y: 400 })
      .mouseUp()
      .perform();
      browser.driver.sleep(3000);
    });
    
    csttextarea_01.getSize().then(function(result){ 
    browser.sleep(3000);
    browser.driver.actions().mouseMove(csttextarea_01, {x: result.width-2, y: result.height-2})
      .mouseDown()
      .mouseMove(csttextarea_01, {y: 200 })
      .mouseUp()
      .perform();
       browser.driver.sleep(3000);
      });
    browser.sleep(3000);
});
});

describe('UI Automation Tests: CSTTextArea component_02', function() {

 let csttextarea_02 = element(by.css('cst-textarea [ placeholder="Placeholder Textarea 2."]'));
 let input_tooltip_02 = element(by.css('#dashboard_csttextarea_02 div div label cst-tooltip span div.tooltip-icon'));

 it('should resize the text area ', () => {

    console.log("\t1.0. should resize the text area "); 
    csttextarea_02.getSize().then(function(result){ 
    browser.sleep(3000);
    browser.driver.actions().mouseMove(csttextarea_02, {x: result.width-2, y: result.height-2})
      .mouseDown()
      .mouseMove(csttextarea_02, {y: 400 })
      .mouseUp()
      .perform();
      browser.driver.sleep(3000);
    });
  });

 it('should click/unclick the Tooltip ', () => {

    console.log("\t2.0. should click/unclick the Tooltip of textarea_02"); 
 
    browser.actions().mouseMove(csttextarea_02).perform();
    browser.driver.sleep(3000);

    browser.wait(input_tooltip_02.click().then(function() { 
      browser.driver.sleep(3000); // timeout to check the above operation with naked eye!
    }),3000);
    browser.driver.sleep(3000)
    input_tooltip_02.click();
    browser.driver.sleep(3000)
  });
});
});
